# Intégration

Intégration de la maquette du site boutique *e-shop*

1.  La page est en full-width.

2. Trouvez une police ressemblante.

3. Font Awesome pour les icônes des réseaux sociaux.

4. Mettez en place une hierarchie de dossier correcte.
  projet >
    [img]>
    [css]>
      style.css
    [js]
      script.js
    index.html

5. Les images sont dans le dossier img. A ré-aranger dans l'arborescence du dossier

6. Bonus : Le caroussel est un vrai, incorporez le javascript que vous trouverez sur internet

Bon travail !
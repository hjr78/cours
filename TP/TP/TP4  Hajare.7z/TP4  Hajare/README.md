# boutique Azzaro

## Colors
* bleu : rgb(103, 220, 255)
* rose : rgb(224, 36, 168)


## Font
* font-family: Arial, Helvetica, sans-serif


## Texts

### Top
	Ma Boutique
	Vente en ligne. Tendance et Déco.

	Besoin d'aide?
	0800 10 28 10
	Du Lundi au Vendredi de 10h à 17h30

	Mon compte
	article(s) dans votre panier.

### Menu
	Accueil  Vetements  Maison  Technologie  Bijoux  Idees Cadeaux

### Middle
	Paiement Sècurisé
	Réglez vos achats en toute sèrènitè sur maboutique.com

	Qui sommes nous?
	Bienvenue chez MaBoutique | MaBoutique est la plus grande boutique en ligne de France consacrèe à la mode et à la beauté pour femmes et hommes. Nous proposons plus de 850 marques ainsi que nos propres collections. N'hésitez plus les livraisons et les retourns sont gratuits. Petraite possible de votre commande dans notre entrepot dus RDV.

	Services
	Livraison sous 48h
	Produits Echangeables

### Bottom 1
	bloc bloc bloc bloc bloc bloc bloc 
	bloc bloc bloc bloc bloc bloc bloc 
	bloc bloc bloc bloc bloc bloc bloc 
	bloc bloc bloc bloc bloc bloc bloc 
	bloc bloc bloc bloc bloc bloc bloc

### Bottom 2
	Newsletter  Promotions   Nouveaux produits  Meilleurs ventes  Mentions légales  Conditions Générales de Vente  Contactez-nous


## Hint
	Regardez la largeur du bandeau
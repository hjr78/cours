<nav class="navbar navbar-expand-lg navbar-light bg-light ">
    
    <div class="container px-4 px-lg-5">

                <a class="navbar-brand" href="#!">Amazon</a>
                <a href="ajouter_produit.php" style="text-decoration: none; color: black;">Ajouter un produit</a>
                <a href="tout_les_produits.php" style="text-decoration: none; color: black;">Consulter tout les produits</a>
               
    </div>
          
 </nav>
       

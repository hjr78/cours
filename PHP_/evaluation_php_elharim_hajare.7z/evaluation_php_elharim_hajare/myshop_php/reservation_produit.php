
<form  method="POST">
    <p>Réserver votre produit ! Il suffit de nous écrire pour le faire : </p>
    <textarea name="message" rows="4" cols="50" required></textarea><br><br>
    <input type="hidden" name="reservation_text" value="reservation_text">
    <input type="submit" value="Je réserve">
</form>